package com.dashword;

import com.dashword.item.ModItems;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DashwordMod implements ModInitializer {

    public static final String MOD_ID = "dashword";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.registerItems();
        LOGGER.info("[DashwordMod] Initialized successfully!");
    }
}
