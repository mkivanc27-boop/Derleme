package com.dashword.mixin;

import com.dashword.item.DashwordItem;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Mixin to allow Dashword to trigger critical hits when the player dashes
 * downward (mimicking the vanilla falling crit condition).
 */
@Mixin(PlayerEntity.class)
public abstract class DashwordCritMixin {

    /**
     * Inject into the critical-hit check. If holding a Dashword and the
     * player has a small positive fallDistance set by the dash mechanic,
     * we allow the crit to register.
     */
    @Inject(method = "attack", at = @At("HEAD"))
    private void onAttack(net.minecraft.entity.Entity target, CallbackInfoReturnable<Void> cir) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        ItemStack held = self.getMainHandStack();

        if (held.getItem() instanceof DashwordItem) {
            // If fallDistance was set by the dash crit opportunity flag,
            // ensure velocity is negative so vanilla crit condition is met.
            if (self.fallDistance > 0 && self.fallDistance < 0.2f) {
                Vec3d vel = self.getVelocity();
                if (vel.y >= 0) {
                    self.setVelocity(vel.x, -0.1, vel.z);
                }
            }
        }
    }
}
