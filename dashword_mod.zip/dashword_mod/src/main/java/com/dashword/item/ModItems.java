package com.dashword.item;

import com.dashword.DashwordMod;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {

    public static final DashwordItem DASHWORD = new DashwordItem(
            ToolMaterials.NETHERITE,
            // attackDamage bonus on top of material base (netherite base = 3, so +5 = 8 total)
            5,
            // attackSpeed
            -2.4f,
            new FabricItemSettings()
                    .maxCount(1)
    );

    public static void registerItems() {
        Registry.register(
                Registries.ITEM,
                new Identifier(DashwordMod.MOD_ID, "dashword"),
                DASHWORD
        );

        // Add to Combat item group
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(DASHWORD);
        });

        DashwordMod.LOGGER.info("[DashwordMod] Items registered.");
    }
}
