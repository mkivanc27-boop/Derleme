package com.dashword.item;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class DashwordItem extends SwordItem {

    // Cooldown in ticks (20 ticks = 1 second)
    public static final int DASH_COOLDOWN_TICKS = 20;
    // Maximum dash distance in blocks
    public static final double MAX_DASH_DISTANCE = 5.0;
    // How many particle steps to spawn along the trail
    private static final int TRAIL_STEPS = 10;

    public DashwordItem(ToolMaterial toolMaterial, int attackDamage, float attackSpeed, Settings settings) {
        super(toolMaterial, attackDamage, attackSpeed, settings);
    }

    /**
     * Right-click triggers the dash.
     */
    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        // Only handle main hand
        if (hand != Hand.MAIN_HAND) {
            return TypedActionResult.pass(stack);
        }

        // Check cooldown
        if (user.getItemCooldownManager().isCoolingDown(this)) {
            return TypedActionResult.fail(stack);
        }

        if (!world.isClient) {
            performDash(user, world);
        }

        // Apply cooldown
        user.getItemCooldownManager().set(this, DASH_COOLDOWN_TICKS);

        return TypedActionResult.success(stack, world.isClient);
    }

    /**
     * Executes the dash logic on the server side.
     */
    private void performDash(PlayerEntity player, World world) {
        Vec3d lookVec = player.getRotationVec(1.0f).normalize();

        // Dash distance = max distance (cooldown is already 0 when we get here after check)
        double dashDistance = MAX_DASH_DISTANCE;

        Vec3d dashVec = lookVec.multiply(dashDistance);

        // Calculate target position
        Vec3d startPos = player.getPos();
        Vec3d targetPos = startPos.add(dashVec);

        // Spawn particle trail before moving
        spawnDashTrail(player, world, startPos, targetPos);

        // Apply velocity instead of teleport so it feels snappy and respects collisions
        player.setVelocity(dashVec.multiply(0.5));
        player.velocityModified = true;

        // Check for critical hit timing: if player is falling (negative Y velocity before dash),
        // trigger a critical amplifier flag via a tag
        // We approximate this by checking if the dash vector has an upward component < -0.3
        // (player looking mostly down while falling = crit opportunity)
        boolean critOpportunity = (lookVec.y < -0.2) && !player.isOnGround();
        if (critOpportunity) {
            // Give a brief strength-like boost via a status flag tag on the stack
            // We handle this by setting the player's fallDistance to simulate a crit
            player.fallDistance = 0.1f;
        }
    }

    /**
     * Spawns blue particle trail between start and target positions.
     */
    private void spawnDashTrail(PlayerEntity player, World world, Vec3d start, Vec3d end) {
        if (!(world instanceof ServerWorld serverWorld)) return;

        Vec3d diff = end.subtract(start);
        for (int i = 0; i <= TRAIL_STEPS; i++) {
            double t = (double) i / TRAIL_STEPS;
            double x = start.x + diff.x * t;
            double y = start.y + diff.y * t + 0.9; // center on player body
            double z = start.z + diff.z * t;

            // Main trail: end rod particles (blue-white)
            serverWorld.spawnParticles(
                    ParticleTypes.END_ROD,
                    x, y, z,
                    3,       // count
                    0.15, 0.15, 0.15, // spread
                    0.02     // speed
            );

            // Secondary trail: soul fire flame for deeper blue
            serverWorld.spawnParticles(
                    ParticleTypes.SOUL_FIRE_FLAME,
                    x, y, z,
                    1,
                    0.1, 0.1, 0.1,
                    0.01
            );
        }
    }

    /**
     * Tick event: show cooldown percentage on action bar while holding.
     */
    @Override
    public void inventoryTick(ItemStack stack, World world, net.minecraft.entity.Entity entity, int slot, boolean selected) {
        super.inventoryTick(stack, world, entity, slot, selected);

        if (!world.isClient) return;
        if (!(entity instanceof PlayerEntity player)) return;
        if (!selected) return;

        // Show cooldown info on action bar
        float cooldownProgress = player.getItemCooldownManager().getCooldownProgress(this, 1.0f);
        if (cooldownProgress > 0f) {
            int ticksLeft = Math.round(cooldownProgress * DASH_COOLDOWN_TICKS);
            int percent = Math.round(cooldownProgress * 100);

            player.sendMessage(
                    Text.literal("⚡ Dash Cooldown: ")
                            .formatted(Formatting.AQUA)
                            .append(Text.literal(percent + "%")
                                    .formatted(percent > 50 ? Formatting.RED : Formatting.YELLOW)),
                    true // action bar
            );
        } else {
            // Ready
            player.sendMessage(
                    Text.literal("⚡ Dash: ")
                            .formatted(Formatting.AQUA)
                            .append(Text.literal("READY")
                                    .formatted(Formatting.GREEN)
                                    .formatted(Formatting.BOLD)),
                    true
            );
        }
    }

    /**
     * The item has enchantment glint (foil) to simulate the blue glow.
     */
    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }

    /**
     * Tooltip showing stats.
     */
    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
        super.appendTooltip(stack, world, tooltip, context);
        tooltip.add(Text.literal("Right-click to Dash").formatted(Formatting.AQUA));
        tooltip.add(Text.literal("Dash Distance: 5 blocks").formatted(Formatting.DARK_AQUA));
        tooltip.add(Text.literal("Cooldown: 1 second").formatted(Formatting.DARK_AQUA));
        tooltip.add(Text.literal("Repair: Netherite Ingot + Ender Pearl").formatted(Formatting.GRAY));
    }
}
