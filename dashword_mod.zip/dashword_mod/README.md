# DashwordMod — Fabric 1.19.4

A Fabric mod that adds the **Dashword**: a netherite-class sword with a blazing blue aesthetic and a directional dash ability.

---

## Features

- **Dashword item** — 8.0 attack damage, netherite durability, enchantment glint (blue glow)
- **Right-click to Dash** — Dashes up to 5 blocks in the direction you're looking (horizontal, vertical, or diagonal)
- **Action Bar Cooldown** — While holding the sword, the dash cooldown % is shown on your action bar
- **Blue Particle Trail** — End rod + soul fire particles spawn along the dash path
- **Critical Hit Dash** — Dashing downward while falling can trigger a critical hit on your next swing
- **Glowing foil** — Sword always shows enchantment glint as a visual blue glow
- **Crafting** — 2× Netherite Ingot + 2× Ender Pearl (diagonal pattern)
- **Repair** — Use Netherite Ingot in anvil, or smithing table

---

## Building

### Requirements
- Java 17+
- Internet connection (Gradle downloads dependencies)

### Steps
```bash
# Clone / unzip the mod folder
cd dashword_mod

# On Linux/Mac
./gradlew build

# On Windows
gradlew.bat build
```

The compiled `.jar` will be in `build/libs/dashword-1.0.0.jar`.

---

## Installing

1. Install [Fabric Loader](https://fabricmc.net/use/) for Minecraft 1.19.4
2. Install [Fabric API](https://modrinth.com/mod/fabric-api) for 1.19.4
3. Drop `dashword-1.0.0.jar` into your `.minecraft/mods/` folder
4. Launch Minecraft 1.19.4 with the Fabric profile

---

## Crafting Recipe

```
[ ]  [E]
[N]  [E]
[N]  [ ]
```
- `E` = Ender Pearl  
- `N` = Netherite Ingot

---

## File Structure

```
dashword_mod/
├── build.gradle
├── gradle.properties
├── settings.gradle
├── gradle/wrapper/gradle-wrapper.properties
└── src/main/
    ├── java/com/dashword/
    │   ├── DashwordMod.java          ← Mod entrypoint
    │   ├── item/
    │   │   ├── DashwordItem.java     ← Sword + dash logic
    │   │   └── ModItems.java         ← Item registration
    │   └── mixin/
    │       └── DashwordCritMixin.java ← Critical hit mixin
    └── resources/
        ├── fabric.mod.json
        ├── dashword.mixins.json
        ├── assets/dashword/
        │   ├── lang/en_us.json
        │   ├── models/item/dashword.json
        │   └── textures/item/dashword.png
        └── data/dashword/recipes/
            ├── dashword.json         ← Crafting recipe
            └── dashword_repair.json  ← Smithing repair
```
